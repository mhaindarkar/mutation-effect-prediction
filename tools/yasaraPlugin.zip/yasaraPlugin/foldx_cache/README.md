This directory is intentionally kept for generated outputs.
